﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class EmployeeBenefitContext : DbContext
    {
        public EmployeeBenefitContext(DbContextOptions<EmployeeBenefitContext> options) : base(options)
        {

        }

        public DbSet<Employee> Employee { get; set; }
        public DbSet<Benefit> Benefit { get; set; }
        public DbSet<EmployeeBenefit> EmployeeBenefit { get; set; }
        public DbSet<SystemConfig> SystemConfig { get; set; }
    }
}

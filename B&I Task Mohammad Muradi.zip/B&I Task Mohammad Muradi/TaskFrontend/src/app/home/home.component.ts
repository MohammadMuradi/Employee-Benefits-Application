import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component'
import { EmployeeBenefitsService } from '../shared/employee-benefits.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private appcomponent: AppComponent,private service: EmployeeBenefitsService) { }

  ngOnInit() {
    this.service.formData = undefined;                  //reset all these when viewing home
    this.service.previousBenefits = [];
    this.service.checkedBenefits = [];
    this.service.employee = undefined;
    this.appcomponent.title = '';
  }

  modifyTitle(title) {
    this.appcomponent.title = title;
  }

}

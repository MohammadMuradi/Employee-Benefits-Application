import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component'
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { EmployeeBenefitsService } from '../shared/employee-benefits.service';
import { Benefit } from '../shared/benefit.model';
import { EmployeeBenefit } from '../shared/employee-benefit.model';
import { Employee } from '../shared/employee.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-edit-employee',
  templateUrl: './add-edit-employee.component.html',
  styleUrls: ['./add-edit-employee.component.css']
})
export class AddEditEmployeeComponent implements OnInit {
  
  constructor(private appcomponent: AppComponent, private service: EmployeeBenefitsService, private toastr: ToastrService
  , private router: Router) { }

  ngOnInit() {
    if (this.service.formData == undefined)           //if add employee and not edit employee is clicked leading to viewing this component
      this.resetForm();                               //resetform sets the employeeId in input to 0
    this.service.getBenefits();                      //refreshes benefits list
  }

  modifyTitle() {
    this.appcomponent.title = '';
  }

  resetForm(form?: NgForm) {
    if (form != null)
      form.form.reset();
    this.service.formData = {
      EmployeeId: 0,                  //setting employeeId to 0 means that I am not editting a previously registered employee who must have id > 1,so I am inserting
      Name: '',
      DOB: undefined,
      Salary: undefined,
    };
  }

  onSubmit(form: NgForm) {
    if (this.service.formData.EmployeeId == 0)           
      this.insertRecord(form);
    else
      this.updateRecord(form);
  }

  insertRecord(form: NgForm) {
    this.service.postEmployee().subscribe(           //uses postemployee method in services class to insert an employee record
      res => {
        this.service.employee = res as Employee;     //gets the employee that I've just added to the database in order to be used when adding his/her benefits
        for (let checked of this.service.checkedBenefits) {       
          if (checked != undefined)
            this.insertEmployeeBenefit(new EmployeeBenefit(this.service.employee.EmployeeId, checked));       
        }      
        this.resetForm(form);
        this.toastr.success('Employee Inserted', 'Employee Benefits Application');
        this.service.getEmployees();
        this.service.checkedBenefits = [];
        this.navigateToHome();
      },
      err => {
        console.log(err);
      }
    )
  }

  updateRecord(form: NgForm) {                    //Extra requirement #5 in this function
    this.service.putEmployee().subscribe(          //inserts the new data of the employee being editted
      res => {
        for (let checked of this.service.checkedBenefits) {     
          if (checked != undefined && this.service.previousBenefits.indexOf(checked) == -1)   //if a benefit checked when submitting and not found in the previous benefits
            this.insertEmployeeBenefit(new EmployeeBenefit(this.service.employee.EmployeeId, checked));      //insert it into employeebenefits
        }
        for (let empbenefit of this.service.employeeBenefitsList) {
          if (empbenefit.EmployeeId == this.service.employee.EmployeeId && this.service.checkedBenefits.indexOf(empbenefit.BenefitId) == -1) {   //if an employee has a benefit and it's not found in the checked benefits when submitting
            this.deleteEmployeeBenefit(empbenefit.EmployeeBenefitId);                                                                           //delete this benefit
          }          
        }
        this.resetForm(form);
        this.toastr.info('Employee Updated', 'Employee Benefits Application');
        this.service.getEmployees();
        this.service.checkedBenefits = [];
        this.navigateToHome(); 
      },
      err => {
        console.log(err);
      }
    )
  }

  updateChecked(benefitId: number) {         //updates the list of checked benefits 
    const index: number = this.service.checkedBenefits.indexOf(benefitId);
    if (index > -1) {
      this.service.checkedBenefits[index] = undefined;
    }
    else {
      this.service.checkedBenefits[this.service.checkedBenefits.length] = benefitId;
    }     
  }

  insertEmployeeBenefit(empBenefit: EmployeeBenefit) {
    this.service.postEmployeeBenefit(empBenefit).subscribe(
      res => {
      },
      err => {
        console.log(err);
      }
    )
  }

  deleteEmployeeBenefit(empBenefitId: number) {
    this.service.deleteEmployeeBenefit(empBenefitId).subscribe(
      res => {
      },
      err => {
        console.log(err);
      }
    )
  }

  checkPrevious(benefitId: number) {            //finds which benefits are acquired by the employee to be editted and check them
    if (this.service.previousBenefits.indexOf(benefitId) > -1)
      return true;
    return false;
  }

  navigateToList() {
    this.router.navigateByUrl('/list');
  }

  navigateToHome() {
    this.router.navigateByUrl('/');
  }

}

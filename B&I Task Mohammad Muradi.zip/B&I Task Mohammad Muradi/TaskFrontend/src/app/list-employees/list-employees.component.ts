import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component'
import { EmployeeBenefitsService } from '../shared/employee-benefits.service';
import { ToastrService } from 'ngx-toastr';
import { Employee } from '../shared/employee.model';
import { Router } from '@angular/router';
import { AddEditEmployeeComponent } from '../add-edit-employee/add-edit-employee.component';

@Component({
  selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.css']
})
export class ListEmployeesComponent implements OnInit {
  employeefound: boolean;          //to specify if an employee has benefits or not when being deleted

  constructor(private appcomponent: AppComponent, private service: EmployeeBenefitsService,
    private toastr: ToastrService, private router: Router) { }

  ngOnInit() {
    this.service.getEmployees();                  //refresh list of employees
    this.service.getEmployeeBenefits();           //refresh list of employee-benefits
    this.appcomponent.title = '- List Employees';    //title of header when viewing this component
  }

  modifyTitle(title) {
    this.appcomponent.title = title;              //crucial to update title when clicking edit
  }

  populateForm(em: Employee) {                        //when clicking edit employee
    this.service.employee = em;
    this.service.formData = Object.assign({}, em);
    for (let empben of this.service.employeeBenefitsList) {
      if (empben.EmployeeId == em.EmployeeId) {
        this.service.previousBenefits.push(empben.BenefitId);        //previous-checked benefits used to be compared with new checked benefits to find out what benefits to be inserted or deleted
        this.service.checkedBenefits.push(empben.BenefitId);         //has the currently checked benefits when editting an employee which are used to be compared with previous-checked and to find out what benefits are checked when clicking edit employee
      }
    }
    this.appcomponent.title = '- Edit Employee';
    this.navigateToAddEdit();
  }

  onDelete(EmployeeId) {                  //when clicking delete employee
    this.employeefound = false;           
    if (confirm('Are you sure to delete this record ?')) {
      for (let empben of this.service.employeeBenefitsList) {
        if (empben.EmployeeId == EmployeeId)                    //find out if the employee to be deleted has benefits or not
          this.employeefound = true;
      }
      if (this.employeefound) {                                    //if the employee to be deleted has benefits     
        for (let empben of this.service.employeeBenefitsList) {
          if (empben.EmployeeId == EmployeeId)
            this.service.deleteEmployeeBenefit(empben.EmployeeBenefitId)     //delete all his benefits first because of the foreign key restraint
              .subscribe(res => {
                this.service.deleteEmployee(EmployeeId)
                  .subscribe(res => {
                    this.service.getEmployees();                              //refresh employees lost
                    this.toastr.warning('Employee Deleted', 'Employee Benefits Application');
                  },
                    err => {
                      console.log(err);
                    });
              },
                err => {
                  console.log(err);
                });
        }
      }
      else {                                                 //if the employee to be deleted has no benefits
        this.service.deleteEmployee(EmployeeId)              //safe to delete
          .subscribe(res => {
            this.service.getEmployees();
            this.toastr.warning('Employee Deleted', 'Employee Benefits Application');
          },
            err => {
              console.log(err);
            });
      }
    }
  }

  navigateToAddEdit() {
    this.router.navigateByUrl('/add-edit');
  }

}

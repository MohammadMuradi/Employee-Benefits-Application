export class EmployeeBenefit {
  EmployeeBenefitId: number = undefined;
  EmployeeId: number;
  BenefitId: number;

  constructor(EmployeeId: number, BenefitId: number) {
    this.EmployeeId = EmployeeId;
    this.BenefitId = BenefitId;
  }
}

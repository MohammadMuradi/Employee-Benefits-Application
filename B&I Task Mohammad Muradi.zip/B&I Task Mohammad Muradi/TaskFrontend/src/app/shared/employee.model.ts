export class Employee {
  EmployeeId: number;
  Name: string;
  DOB: Date;
  Salary: number;
}
